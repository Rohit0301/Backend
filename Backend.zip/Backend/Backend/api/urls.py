from django.contrib import admin
from django.urls import path, include
from .views import HistoryDateView, ReceivedHistoryView, OverAllStats, SentHistoryView
app_name="api"
urlpatterns = [
    path('get_all_dates/',HistoryDateView.as_view(), name="all history dates"),
    path('get_received_history/<id>',ReceivedHistoryView.as_view(), name="received history data"),
    path('get_sent_history/<id>',SentHistoryView.as_view(), name="received history data"),
    path('stats/<id>',OverAllStats.as_view(), name="overall stats data"),
]