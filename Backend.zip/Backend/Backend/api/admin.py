from django.contrib import admin
from .models import SentHistory, ReceivedHistory, HistoryDate

admin.site.register(SentHistory)
admin.site.register(ReceivedHistory)
admin.site.register(HistoryDate)
