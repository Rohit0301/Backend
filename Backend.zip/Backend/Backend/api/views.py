from django.shortcuts import render
from rest_framework.views import APIView
from django.db.models import Sum
from rest_framework import status
from .serializers import HistoryDateSerializer, ReceivedHistorySerializer, SentHistorySerializer
from rest_framework.response import Response
from .models import HistoryDate, ReceivedHistory, SentHistory
from rest_framework.parsers import JSONParser   
import datetime
import json
import ast
# Create your views here.
class HistoryDateView(APIView):
    serializer_class = HistoryDateSerializer
    def get(self,request):
        dates = HistoryDate.objects.all().order_by('-start_date')
        print(dates)
        data = []
        for date in dates:
            temp = {}
            temp['start_date'] = date.start_date
            temp['end_date'] = date.end_date
            temp['id'] = date.id
            temp['in_progress'] = date.in_progress
            data.append(temp)
        return Response(data, status=status.HTTP_200_OK)

    def post(self,request):
        post_serializer=HistoryDateSerializer(data={})
        is_in_progress = HistoryDate.objects.filter(in_progress=True)
        if(len(is_in_progress) > 0):
            return Response("Already in progress", status=status.HTTP_204_NO_CONTENT)
        if post_serializer.is_valid():
            post_serializer.save()
            return Response("Added successfully",status=status.HTTP_201_CREATED)
        return Response(post_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    def put(self,request):
        # try:
            body = request.body.decode('utf-8')
            body = json.dumps(body, indent=4, sort_keys=True)
            body = ast.literal_eval(body)
            body = json.loads(body)
            history_date = HistoryDate.objects.get(id=body["id"])
            print(history_date)
            history_date.in_progress = True
            history_date.end_date = datetime.datetime.now() 
            history_date.save()
            return Response("Ended successfully",status=status.HTTP_200_OK)
        # except: 
        #     return Response("Something went wrong", status=status.HTTP_400_BAD_REQUEST)
    
class ReceivedHistoryView(APIView):
    serializer_class = ReceivedHistorySerializer

    def get(self,request,id):
        data = []
        history = ReceivedHistory.objects.filter(history_date=id).order_by('-date')
        for h in history:
            temp = {}
            temp['id'] = h.id
            temp['date'] = h.date
            temp['two_thousand'] = h.two_thousand
            temp['five_hundred'] = h.five_hundred
            temp['two_hundred'] = h.two_hundred
            temp['hundred'] = h.hundred
            temp['fifty'] = h.fifty
            temp['two_thousand_total'] = h.two_thousand * 2000
            temp['five_hundred_total'] = h.five_hundred * 500
            temp['two_hundred_total'] = h.two_hundred * 200
            temp['hundred_total'] = h.hundred * 100
            temp['fifty_total'] = h.fifty * 50
            temp['amount'] = h.amount
            data.append(temp)
        return Response(data,status=status.HTTP_200_OK)
    def post(self,request,id):
        post_serializer=ReceivedHistorySerializer(data=request.data)
        if(post_serializer.is_valid()):
            post_serializer.save()
            return Response("Added successfully",status=status.HTTP_201_CREATED)
        return Response(post_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class SentHistoryView(APIView):
    serializer_class = SentHistorySerializer

    def get(self,request,id):
        data = []
        history = SentHistory.objects.filter(history_date=id).order_by('-date')
        for h in history:
            temp = {}
            temp['id'] = h.id
            temp['date'] = h.date
            temp['name'] = h.name
            temp['two_thousand'] = h.two_thousand
            temp['five_hundred'] = h.five_hundred
            temp['two_hundred'] = h.two_hundred
            temp['hundred'] = h.hundred
            temp['fifty'] = h.fifty
            temp['two_thousand_total'] = h.two_thousand * 2000
            temp['five_hundred_total'] = h.five_hundred * 500
            temp['two_hundred_total'] = h.two_hundred * 200
            temp['hundred_total'] = h.hundred * 100
            temp['fifty_total'] = h.fifty * 50
            temp['amount'] = h.amount
            data.append(temp)
        return Response(data,status=status.HTTP_200_OK)
    def post(self,request,id):
        post_serializer=SentHistorySerializer(data=request.data)
        if(post_serializer.is_valid()):
            post_serializer.save()
            return Response("Added successfully",status=status.HTTP_201_CREATED)
        return Response(post_serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class OverAllStats(APIView):
    def get(self,request,id):   
        data = {}
        # received
        received = {}
        two_thousand = 0
        five_hundred = 0
        two_hundred = 0
        hundred = 0
        fifty = 0
        try:
            two_thousand = ReceivedHistory.objects.filter(history_date=id).aggregate(Sum('two_thousand'))['two_thousand__sum']
            five_hundred = ReceivedHistory.objects.filter(history_date=id).aggregate(Sum('five_hundred'))['five_hundred__sum'] 
            two_hundred = ReceivedHistory.objects.filter(history_date=id).aggregate(Sum('two_hundred'))['two_hundred__sum']
            hundred = ReceivedHistory.objects.filter(history_date=id).aggregate(Sum('hundred'))['hundred__sum'] 
            fifty = ReceivedHistory.objects.filter(history_date=id).aggregate(Sum('fifty'))['fifty__sum'] 
        except:
            pass
        received = {
                "two_thousand": two_thousand,
                "five_hundred": five_hundred,
                "two_hundred": two_hundred,
                "hundred": hundred,
                "fifty": fifty,
                "two_thousand_total": two_thousand * 2000,
                "five_hundred_total": five_hundred * 500,
                "two_hundred_total": two_hundred * 200,
                "hundred_total": hundred * 100,
                "fifty_total": fifty * 50,
        }
        received["total"] = received["two_thousand_total"]+received["five_hundred_total"]+received["two_hundred_total"]+received["hundred_total"]+received["fifty_total"]
        data["received"] = received

        # sent
        send = {}
        s_two_thousand = 0
        s_five_hundred = 0
        s_two_hundred = 0
        s_hundred = 0
        s_fifty = 0
        try:
            s_two_thousand = SentHistory.objects.filter(history_date=id).aggregate(Sum('two_thousand'))['two_thousand__sum'] | 0
            s_five_hundred = SentHistory.objects.filter(history_date=id).aggregate(Sum('five_hundred'))['five_hundred__sum'] | 0
            s_two_hundred = SentHistory.objects.filter(history_date=id).aggregate(Sum('two_hundred'))['two_hundred__sum'] | 0
            s_hundred = SentHistory.objects.filter(history_date=id).aggregate(Sum('hundred'))['hundred__sum'] |  0
            s_fifty = SentHistory.objects.filter(history_date=id).aggregate(Sum('fifty'))['fifty__sum'] | 0
        except:
            pass
        sent = {
                "two_thousand": s_two_thousand,
                "five_hundred": s_five_hundred,
                "two_hundred": s_two_hundred,
                "hundred": s_hundred,
                "fifty": s_fifty,
                "two_thousand_total": s_two_thousand * 2000,
                "five_hundred_total": s_five_hundred * 500,
                "two_hundred_total": s_two_hundred * 200,
                "hundred_total": s_hundred * 100,
                "fifty_total": s_fifty * 50,
        }
        sent["total"] = sent["two_thousand_total"]+sent["five_hundred_total"]+sent["two_hundred_total"]+sent["hundred_total"]+sent["fifty_total"]
        data["sent"] = sent

        remaining = {
            "two_thousand": two_thousand - s_two_thousand,
            "five_hundred": five_hundred - s_five_hundred,
            "two_hundred": two_hundred - s_two_hundred,
            "hundred": hundred - s_hundred,
            "fifty": fifty - s_fifty,
            "two_thousand_total": (two_thousand - s_two_thousand) * 2000,
            "five_hundred_total": (five_hundred - s_five_hundred) * 500,
            "two_hundred_total": (two_hundred - s_two_hundred) * 200,
            "hundred_total": (hundred - s_hundred) * 100,
            "fifty_total": (fifty - s_fifty) * 50,
        }
        remaining["total"] = remaining["two_thousand_total"]+remaining["five_hundred_total"]+remaining["two_hundred_total"]+remaining["hundred_total"]+remaining["fifty_total"]
        data["remaining"] = remaining
        return Response(data,status=status.HTTP_200_OK)