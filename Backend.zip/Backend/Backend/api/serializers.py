from rest_framework import serializers
from .models import SentHistory, ReceivedHistory, HistoryDate

class HistoryDateSerializer(serializers.ModelSerializer):
    class Meta:
        model=HistoryDate
        fields='__all__'

class ReceivedHistorySerializer(serializers.ModelSerializer):
    class Meta:
        model=ReceivedHistory
        fields='__all__'

class SentHistorySerializer(serializers.ModelSerializer):
    class Meta:
        model=SentHistory
        fields='__all__'