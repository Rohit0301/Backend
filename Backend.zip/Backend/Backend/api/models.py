from django.db import models

# Create your models here.

class HistoryDate(models.Model):
    id = models.AutoField(primary_key=True)
    start_date = models.DateTimeField(auto_now_add = True)
    end_date = models.DateTimeField(null=True,blank=True)
    in_progress = models.BooleanField(default=True)
    def __str__(self):
        return '%s' % (self.id)

class SentHistory(models.Model):
    id = models.AutoField(primary_key=True)
    date = models.DateTimeField()
    name = models.CharField(max_length=100)
    two_thousand = models.IntegerField()
    five_hundred = models.IntegerField()
    two_hundred = models.IntegerField()
    hundred = models.IntegerField()
    fifty = models.IntegerField()
    amount = models.IntegerField(default=0)
    history_date = models.ForeignKey(
        HistoryDate,
        on_delete=models.CASCADE,
        verbose_name="History Date",
    )
    def __str__(self):
        return '%s' % (self.id)

class ReceivedHistory(models.Model):
    id = models.AutoField(primary_key=True)
    date = models.DateTimeField()
    two_thousand = models.IntegerField()
    five_hundred = models.IntegerField()
    two_hundred = models.IntegerField()
    hundred = models.IntegerField()
    amount = models.IntegerField(default=0)
    fifty = models.IntegerField()
    history_date = models.ForeignKey(
        HistoryDate,
        on_delete=models.CASCADE,
        verbose_name="History Date",
    )
    def __str__(self):
        return '%s' % (self.id)

